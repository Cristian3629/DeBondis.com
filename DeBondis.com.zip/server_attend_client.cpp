#include "server_attend_client.h"
#include "server_date.h"
#include <iostream> //cout
#include "server.h"
#include <string.h>
#include <map>
#include <utility>
#include <string>
#include <vector>

using std::cout;
using std::endl;
using std::string;
using std::vector;
using std::pair;

/**/
AttendClient::AttendClient(Server* serverRef,SocketConnector* connectorRef)
:server(serverRef),connector(connectorRef),estate(true){
  value = 0;
  std::cerr << "Cliente conectado." << std::endl;
  mymap.insert(pair<string,int>("A",1));
  mymap.insert(pair<string,int>("F",2));
  mymap.insert(pair<string,int>("R",3));
  mymap.insert(pair<string,int>("L",4));
}

void AttendClient::ejecuteCommand(string& command,vector<int>& parameters){
  int operation = mymap[command];
  switch (operation){
    case 1:
      ejecuteCommandA(parameters);
      break;
    case 2:
      ejecuteCommandF(parameters);
      break;
    case 3:
      ejecuteCommandR(parameters);
      break;
    case 4:
      ejecuteCommandL(parameters);
      break;
  }
}

void AttendClient::sendError(){
  std::cout << "AttendClient::sendError()" << std::endl;
}
AttendClient::~AttendClient(){
}


string AttendClient::getCommand(){
  char command[2] = " ";
  connector->creceive(command,1);
  string mycommand(command);
  /*Recibir '-' avis de que no existen mas consultas por parte del cliente*/
  if (strncmp(command,"-",1) == 0){
    estate = false;
  }else{
    std::cerr << "Comando "<<command<<" recibido." << std::endl;
  }
  return mycommand;
}

vector<int> AttendClient::getParameters(string command){
  int buffer;
  vector<int> parameters;
  int size = getNumberOfBlocks(command);
  for (int i = 0; i < size; i++){
    connector->creceive(&buffer,sizeof(buffer));
    parameters.push_back(buffer);
  }
  return parameters;
}


void AttendClient::run(){
  string command = getCommand();
  while (estate){
    vector<int> parameters = getParameters(command);
    ejecuteCommand(command,parameters);
    command = getCommand();
  }
  std::cerr << "Cliente desconectado." << std::endl;
}

void AttendClient::join(){
  if (thread.joinable()){
    thread.join();
  }
}

void AttendClient::ejecuteCommandA(vector<int>& parameters){
  server->addBus(parameters[1],parameters[0]);
  uint32_t numberBus = parameters[1];
  uint8_t answer = 0x00;
  connector->csend(&answer,sizeof(answer));
  connector->csend(&numberBus,sizeof(numberBus));
}

void AttendClient::ejecuteCommandF(vector<int>& parameters){
    std::vector<Colectivo*> colectivos = server->getBussOfNumber(parameters[1]);
    if (colectivos[0]->getTimeToStop(parameters[2])<0){
      uint8_t answer = 0xff;
      connector->csend(&answer,sizeof(answer));
    }else{
      Date dateQuery(parameters[0]);
      int diferencia = 600000;
      for (size_t i = 0; i < colectivos.size(); i++) {
        int time = colectivos[i]->getTimeToStop(parameters[2]) / 60;
        Date busDate = colectivos[i]->getDate();
        busDate.incrementeMinute(time);
        int diferenciaAux = dateQuery - busDate;
        if (diferenciaAux >= 0 && diferenciaAux < diferencia){
          diferencia = diferenciaAux;
        }
      }
      uint8_t answer = 0x02;
      uint32_t seconds = diferencia/60;
      connector->csend(&answer,sizeof(answer));
      connector->csend(&seconds,sizeof(seconds));
    }
  }

void AttendClient::ejecuteCommandL(vector<int>& parameters){
  std::vector<Colectivo*> colectivos = server->getBuss();
  uint8_t answer;
  if (colectivos.size()>0){
    Date dataQuery(parameters[0]);
    int pos = 0;
    int diferenciaActual = 6000000;
    for (size_t i = 1; i < colectivos.size(); i++){
      Colectivo* colectivo = colectivos[i];
      int difParadaBus = colectivo->getTimeToStop(parameters[1],parameters[2]);
      if (0 <= difParadaBus){
        if (difParadaBus < diferenciaActual){
          diferenciaActual = difParadaBus;
          pos = i;
        }
      }
    }
    answer = 0x03;
    connector->csend(&answer,sizeof(answer));
    uint32_t linea = colectivos[pos]->getLinea();
    uint32_t segundos = diferenciaActual;
    connector->csend(&linea,sizeof(linea));
    connector->csend(&segundos,sizeof(segundos));
  }else{
    answer = 0xff;
    connector->csend(&answer,sizeof(answer));
  }
}


void AttendClient::ejecuteCommandR(std::vector<int>& parameters){
  std::vector<Colectivo*> colectivos = server->getBuss();
  Date dataQuery(parameters[0]);
  int pos = 0;
  int sumaActual = 6000000;
  int tiempoParaLlegarActual = 0;
  for (size_t i = 1; i < colectivos.size(); i++){
    Colectivo* colectivo = colectivos[i];
    int difParadaBus = colectivo->getTimeToStop(parameters[1],parameters[2]);
    int timeBuss1 = colectivo->getTimeToStop(parameters[1]);
    Date dateBus = colectivo->getDate();
    int minute = timeBuss1/60;
    dateBus.incrementeMinute(minute);
    dateBus.addSeconds(timeBuss1 - minute*60);
    int tiempoParaLlegar = dataQuery - dateBus;
    if (0<tiempoParaLlegar &&  0 <= difParadaBus){
      if (tiempoParaLlegar + difParadaBus <= sumaActual){
        sumaActual = tiempoParaLlegar + difParadaBus;
        tiempoParaLlegarActual = difParadaBus + tiempoParaLlegar;
        pos = i;
      }
    }
  }
  uint8_t answer = 0x04;
  connector->csend(&answer,sizeof(answer));
  uint32_t parameter = colectivos[pos]->getLinea();
  uint32_t parameter1 = tiempoParaLlegarActual;
  connector->csend(&parameter,sizeof(parameter));
  connector->csend(&parameter1,sizeof(parameter1));
}

AttendClient::AttendClient(AttendClient&& other){
  thread = std::move(other.thread);
  server = other.server;
  connector = other.connector;
  mymap = std::move(other.mymap);
  estate = other.estate;
  other.server = nullptr;
  other.connector = nullptr;
  other.estate = false;
  other.value = -1; /*defino que quedó en un estado no valido*/
}
AttendClient& AttendClient::operator=(AttendClient&& other){
  thread = std::move(other.thread);
  server = other.server;
  connector = other.connector;
  mymap = std::move(other.mymap);
  estate = other.estate;
  other.server = nullptr;
  other.connector = nullptr;
  other.estate = false;
  other.value = -1; /*defino que quedó en un estado no valido*/
  return (*this);
}


int AttendClient::getNumberOfBlocks(string command){
  if (command == "A"){
    return 2;
  }
  return 3;
}

bool AttendClient::isActive(){
  return estate;
}
